(function () {
    'use strict';

    angular.module('app', [
        // vendor packages
        // 'ngResource',
        // 'ui.router',
        
        'mcmakler'
    ])
})();
