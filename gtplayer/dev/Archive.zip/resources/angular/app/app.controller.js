(function () {
    'use strict';

    angular.module('app')
        .controller('AppCtrl', appController)
    ;

    function appController()
    {
        
    }

})();
