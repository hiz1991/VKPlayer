(function () {
    'use strict';

    angular.module('mcmakler')
        .controller('TestCtrl', testController)
    ;

    function testController($scope, $http)
    {
    	$scope.address = {};

        $scope.save	= function (address) {
        	// used promise, for it was asked to create reusable code
        	// could have done in many other ways including syncronious request
        	// but it would hang the browser, so promise was used
        	var newAddress = getLongLat(address);
        	newAddress.then(function(data) {
        		console.log(data);
        		$scope.address = data;
        	});
        }

        function getLongLat(address) {
        	delete address.location;
        	delete address.error;
        	delete address.successful;
        	delete address.message;

        	var apiKey = 'AIzaSyBRva77Iu_4BRLcrYcymYkWY6dCmO2KTYA';
        	var addr = address.housenumber + ' ' + address.street + ' ' + address.city
        	var url = 'https://maps.googleapis.com/maps/api/geocode/json?address='+addr+'&key='+apiKey;
        	var promise = $http.get(url)
    	    .then(function(response) {
    	    	if (response.data.status == "ZERO_RESULTS"){
    	    		address.error = 'Invalid address';
        	    	address.successful = false;
		    	    address.message = address.error;
        	    	return address;

    	    	} else if (response.data.status != "OK"){
    	    		address.error = 'Unknown error';
		    	    address.message = address.error;
        	    	address.successful = false;
        	    	return address;

    	    	} else {
	    	    	address.successful = true;
	    	    	address.location = response.data.results[0].geometry.location;
	    	    	address.message = 'The coordinates for this address are: ' + address.location.lat + ', ' + address.location.lng;
	    	    	return address;
    	    	}

    	    }, function (response) {
    	    	address.successful = false;
	    		address.error = 'Error with request';
	    	    address.message = address.error;

	    		return address;
    	    });
        	return promise;
        }
    }

})();
