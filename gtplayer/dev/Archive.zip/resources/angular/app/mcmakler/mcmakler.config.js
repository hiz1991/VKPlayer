(function () {
    'use strict';

    angular
        .module('mcmakler')
    ;

})();
