(function () {
    'use strict';

    angular.module('app', [
        // vendor packages
        // 'ngResource',
        // 'ui.router',
        
        'mcmakler'
    ])
})();

(function () {
    'use strict';

    angular.module('mcmakler', [])
    ;

})();

(function () {
    'use strict';

    angular.module('app')
        .config(appConfig)
    ;

    function appConfig()
    {

    }
    
})();

(function () {
    'use strict';

    angular.module('app')
        .controller('AppCtrl', appController)
    ;

    function appController()
    {
        
    }

})();

(function () {
    'use strict';

    angular
        .module('mcmakler')
    ;

})();

(function () {
    'use strict';

    testController.$inject = ["$scope", "$http"];
    angular.module('mcmakler')
        .controller('TestCtrl', testController)
    ;

    function testController($scope, $http)
    {
    	$scope.address = {};

        $scope.save	= function (address) {
        	// used promise, for it was asked to create reusable code
        	// could have done in many other ways including syncronious request
        	// but it would hang the browser, so promise was used
        	var newAddress = getLongLat(address);
        	newAddress.then(function(data) {
        		console.log(data);
        		$scope.address = data;
        	});
        }

        function getLongLat(address) {
        	delete address.location;
        	delete address.error;
        	delete address.successful;
        	delete address.message;

        	var apiKey = 'AIzaSyBRva77Iu_4BRLcrYcymYkWY6dCmO2KTYA';
        	var addr = address.housenumber + ' ' + address.street + ' ' + address.city
        	var url = 'https://maps.googleapis.com/maps/api/geocode/json?address='+addr+'&key='+apiKey;
        	var promise = $http.get(url)
    	    .then(function(response) {
    	    	if (response.data.status == "ZERO_RESULTS"){
    	    		address.error = 'Invalid address';
        	    	address.successful = false;
		    	    address.message = address.error;
        	    	return address;

    	    	} else if (response.data.status != "OK"){
    	    		address.error = 'Unknown error';
		    	    address.message = address.error;
        	    	address.successful = false;
        	    	return address;

    	    	} else {
	    	    	address.successful = true;
	    	    	address.location = response.data.results[0].geometry.location;
	    	    	address.message = 'The coordinates for this address are: ' + address.location.lat + ', ' + address.location.lng;
	    	    	return address;
    	    	}

    	    }, function (response) {
    	    	address.successful = false;
	    		address.error = 'Error with request';
	    	    address.message = address.error;

	    		return address;
    	    });
        	return promise;
        }
    }

})();

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5tb2R1bGUuanMiLCJtY21ha2xlci9tY21ha2xlci5tb2R1bGUuanMiLCJhcHAuY29uZmlnLmpzIiwiYXBwLmNvbnRyb2xsZXIuanMiLCJtY21ha2xlci9tY21ha2xlci5jb25maWcuanMiLCJtY21ha2xlci9tY21ha2xlci5jb250cm9sbGVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLENBQUEsWUFBQTtJQUNBOztJQUVBLFFBQUEsT0FBQSxPQUFBOzs7OztRQUtBOzs7O0FDUkEsQ0FBQSxZQUFBO0lBQ0E7O0lBRUEsUUFBQSxPQUFBLFlBQUE7Ozs7O0FDSEEsQ0FBQSxZQUFBO0lBQ0E7O0lBRUEsUUFBQSxPQUFBO1NBQ0EsT0FBQTs7O0lBR0EsU0FBQTtJQUNBOzs7Ozs7QUNSQSxDQUFBLFlBQUE7SUFDQTs7SUFFQSxRQUFBLE9BQUE7U0FDQSxXQUFBLFdBQUE7OztJQUdBLFNBQUE7SUFDQTs7Ozs7O0FDUkEsQ0FBQSxZQUFBO0lBQ0E7O0lBRUE7U0FDQSxPQUFBOzs7OztBQ0pBLENBQUEsWUFBQTtJQUNBOzs7SUFFQSxRQUFBLE9BQUE7U0FDQSxXQUFBLFlBQUE7OztJQUdBLFNBQUEsZUFBQSxRQUFBO0lBQ0E7S0FDQSxPQUFBLFVBQUE7O1FBRUEsT0FBQSxPQUFBLFVBQUEsU0FBQTs7OztTQUlBLElBQUEsYUFBQSxXQUFBO1NBQ0EsV0FBQSxLQUFBLFNBQUEsTUFBQTtVQUNBLFFBQUEsSUFBQTtVQUNBLE9BQUEsVUFBQTs7OztRQUlBLFNBQUEsV0FBQSxTQUFBO1NBQ0EsT0FBQSxRQUFBO1NBQ0EsT0FBQSxRQUFBO1NBQ0EsT0FBQSxRQUFBO1NBQ0EsT0FBQSxRQUFBOztTQUVBLElBQUEsU0FBQTtTQUNBLElBQUEsT0FBQSxRQUFBLGNBQUEsTUFBQSxRQUFBLFNBQUEsTUFBQSxRQUFBO1NBQ0EsSUFBQSxNQUFBLDZEQUFBLEtBQUEsUUFBQTtTQUNBLElBQUEsVUFBQSxNQUFBLElBQUE7VUFDQSxLQUFBLFNBQUEsVUFBQTtVQUNBLElBQUEsU0FBQSxLQUFBLFVBQUEsZUFBQTtXQUNBLFFBQUEsUUFBQTtjQUNBLFFBQUEsYUFBQTtXQUNBLFFBQUEsVUFBQSxRQUFBO2NBQ0EsT0FBQTs7aUJBRUEsSUFBQSxTQUFBLEtBQUEsVUFBQSxLQUFBO1dBQ0EsUUFBQSxRQUFBO1dBQ0EsUUFBQSxVQUFBLFFBQUE7Y0FDQSxRQUFBLGFBQUE7Y0FDQSxPQUFBOztpQkFFQTtXQUNBLFFBQUEsYUFBQTtXQUNBLFFBQUEsV0FBQSxTQUFBLEtBQUEsUUFBQSxHQUFBLFNBQUE7V0FDQSxRQUFBLFVBQUEsMkNBQUEsUUFBQSxTQUFBLE1BQUEsT0FBQSxRQUFBLFNBQUE7V0FDQSxPQUFBOzs7WUFHQSxVQUFBLFVBQUE7VUFDQSxRQUFBLGFBQUE7T0FDQSxRQUFBLFFBQUE7VUFDQSxRQUFBLFVBQUEsUUFBQTs7T0FFQSxPQUFBOztTQUVBLE9BQUE7Ozs7O0FBS0EiLCJmaWxlIjoiYW5ndWxhci5qcyIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiAoKSB7XG4gICAgJ3VzZSBzdHJpY3QnO1xuXG4gICAgYW5ndWxhci5tb2R1bGUoJ2FwcCcsIFtcbiAgICAgICAgLy8gdmVuZG9yIHBhY2thZ2VzXG4gICAgICAgIC8vICduZ1Jlc291cmNlJyxcbiAgICAgICAgLy8gJ3VpLnJvdXRlcicsXG4gICAgICAgIFxuICAgICAgICAnbWNtYWtsZXInXG4gICAgXSlcbn0pKCk7XG4iLCIoZnVuY3Rpb24gKCkge1xuICAgICd1c2Ugc3RyaWN0JztcblxuICAgIGFuZ3VsYXIubW9kdWxlKCdtY21ha2xlcicsIFtdKVxuICAgIDtcblxufSkoKTtcbiIsIihmdW5jdGlvbiAoKSB7XG4gICAgJ3VzZSBzdHJpY3QnO1xuXG4gICAgYW5ndWxhci5tb2R1bGUoJ2FwcCcpXG4gICAgICAgIC5jb25maWcoYXBwQ29uZmlnKVxuICAgIDtcblxuICAgIGZ1bmN0aW9uIGFwcENvbmZpZygpXG4gICAge1xuXG4gICAgfVxuICAgIFxufSkoKTtcbiIsIihmdW5jdGlvbiAoKSB7XG4gICAgJ3VzZSBzdHJpY3QnO1xuXG4gICAgYW5ndWxhci5tb2R1bGUoJ2FwcCcpXG4gICAgICAgIC5jb250cm9sbGVyKCdBcHBDdHJsJywgYXBwQ29udHJvbGxlcilcbiAgICA7XG5cbiAgICBmdW5jdGlvbiBhcHBDb250cm9sbGVyKClcbiAgICB7XG4gICAgICAgIFxuICAgIH1cblxufSkoKTtcbiIsIihmdW5jdGlvbiAoKSB7XG4gICAgJ3VzZSBzdHJpY3QnO1xuXG4gICAgYW5ndWxhclxuICAgICAgICAubW9kdWxlKCdtY21ha2xlcicpXG4gICAgO1xuXG59KSgpO1xuIiwiKGZ1bmN0aW9uICgpIHtcbiAgICAndXNlIHN0cmljdCc7XG5cbiAgICBhbmd1bGFyLm1vZHVsZSgnbWNtYWtsZXInKVxuICAgICAgICAuY29udHJvbGxlcignVGVzdEN0cmwnLCB0ZXN0Q29udHJvbGxlcilcbiAgICA7XG5cbiAgICBmdW5jdGlvbiB0ZXN0Q29udHJvbGxlcigkc2NvcGUsICRodHRwKVxuICAgIHtcbiAgICBcdCRzY29wZS5hZGRyZXNzID0ge307XG5cbiAgICAgICAgJHNjb3BlLnNhdmVcdD0gZnVuY3Rpb24gKGFkZHJlc3MpIHtcbiAgICAgICAgXHQvLyB1c2VkIHByb21pc2UsIGZvciBpdCB3YXMgYXNrZWQgdG8gY3JlYXRlIHJldXNhYmxlIGNvZGVcbiAgICAgICAgXHQvLyBjb3VsZCBoYXZlIGRvbmUgaW4gbWFueSBvdGhlciB3YXlzIGluY2x1ZGluZyBzeW5jcm9uaW91cyByZXF1ZXN0XG4gICAgICAgIFx0Ly8gYnV0IGl0IHdvdWxkIGhhbmcgdGhlIGJyb3dzZXIsIHNvIHByb21pc2Ugd2FzIHVzZWRcbiAgICAgICAgXHR2YXIgbmV3QWRkcmVzcyA9IGdldExvbmdMYXQoYWRkcmVzcyk7XG4gICAgICAgIFx0bmV3QWRkcmVzcy50aGVuKGZ1bmN0aW9uKGRhdGEpIHtcbiAgICAgICAgXHRcdGNvbnNvbGUubG9nKGRhdGEpO1xuICAgICAgICBcdFx0JHNjb3BlLmFkZHJlc3MgPSBkYXRhO1xuICAgICAgICBcdH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gZ2V0TG9uZ0xhdChhZGRyZXNzKSB7XG4gICAgICAgIFx0ZGVsZXRlIGFkZHJlc3MubG9jYXRpb247XG4gICAgICAgIFx0ZGVsZXRlIGFkZHJlc3MuZXJyb3I7XG4gICAgICAgIFx0ZGVsZXRlIGFkZHJlc3Muc3VjY2Vzc2Z1bDtcbiAgICAgICAgXHRkZWxldGUgYWRkcmVzcy5tZXNzYWdlO1xuXG4gICAgICAgIFx0dmFyIGFwaUtleSA9ICdBSXphU3lCUnZhNzdJdV80QlJMY3JZY3ltWWtXWTZkQ21PMktUWUEnO1xuICAgICAgICBcdHZhciBhZGRyID0gYWRkcmVzcy5ob3VzZW51bWJlciArICcgJyArIGFkZHJlc3Muc3RyZWV0ICsgJyAnICsgYWRkcmVzcy5jaXR5XG4gICAgICAgIFx0dmFyIHVybCA9ICdodHRwczovL21hcHMuZ29vZ2xlYXBpcy5jb20vbWFwcy9hcGkvZ2VvY29kZS9qc29uP2FkZHJlc3M9JythZGRyKycma2V5PScrYXBpS2V5O1xuICAgICAgICBcdHZhciBwcm9taXNlID0gJGh0dHAuZ2V0KHVybClcbiAgICBcdCAgICAudGhlbihmdW5jdGlvbihyZXNwb25zZSkge1xuICAgIFx0ICAgIFx0aWYgKHJlc3BvbnNlLmRhdGEuc3RhdHVzID09IFwiWkVST19SRVNVTFRTXCIpe1xuICAgIFx0ICAgIFx0XHRhZGRyZXNzLmVycm9yID0gJ0ludmFsaWQgYWRkcmVzcyc7XG4gICAgICAgIFx0ICAgIFx0YWRkcmVzcy5zdWNjZXNzZnVsID0gZmFsc2U7XG5cdFx0ICAgIFx0ICAgIGFkZHJlc3MubWVzc2FnZSA9IGFkZHJlc3MuZXJyb3I7XG4gICAgICAgIFx0ICAgIFx0cmV0dXJuIGFkZHJlc3M7XG5cbiAgICBcdCAgICBcdH0gZWxzZSBpZiAocmVzcG9uc2UuZGF0YS5zdGF0dXMgIT0gXCJPS1wiKXtcbiAgICBcdCAgICBcdFx0YWRkcmVzcy5lcnJvciA9ICdVbmtub3duIGVycm9yJztcblx0XHQgICAgXHQgICAgYWRkcmVzcy5tZXNzYWdlID0gYWRkcmVzcy5lcnJvcjtcbiAgICAgICAgXHQgICAgXHRhZGRyZXNzLnN1Y2Nlc3NmdWwgPSBmYWxzZTtcbiAgICAgICAgXHQgICAgXHRyZXR1cm4gYWRkcmVzcztcblxuICAgIFx0ICAgIFx0fSBlbHNlIHtcblx0ICAgIFx0ICAgIFx0YWRkcmVzcy5zdWNjZXNzZnVsID0gdHJ1ZTtcblx0ICAgIFx0ICAgIFx0YWRkcmVzcy5sb2NhdGlvbiA9IHJlc3BvbnNlLmRhdGEucmVzdWx0c1swXS5nZW9tZXRyeS5sb2NhdGlvbjtcblx0ICAgIFx0ICAgIFx0YWRkcmVzcy5tZXNzYWdlID0gJ1RoZSBjb29yZGluYXRlcyBmb3IgdGhpcyBhZGRyZXNzIGFyZTogJyArIGFkZHJlc3MubG9jYXRpb24ubGF0ICsgJywgJyArIGFkZHJlc3MubG9jYXRpb24ubG5nO1xuXHQgICAgXHQgICAgXHRyZXR1cm4gYWRkcmVzcztcbiAgICBcdCAgICBcdH1cblxuICAgIFx0ICAgIH0sIGZ1bmN0aW9uIChyZXNwb25zZSkge1xuICAgIFx0ICAgIFx0YWRkcmVzcy5zdWNjZXNzZnVsID0gZmFsc2U7XG5cdCAgICBcdFx0YWRkcmVzcy5lcnJvciA9ICdFcnJvciB3aXRoIHJlcXVlc3QnO1xuXHQgICAgXHQgICAgYWRkcmVzcy5tZXNzYWdlID0gYWRkcmVzcy5lcnJvcjtcblxuXHQgICAgXHRcdHJldHVybiBhZGRyZXNzO1xuICAgIFx0ICAgIH0pO1xuICAgICAgICBcdHJldHVybiBwcm9taXNlO1xuICAgICAgICB9XG4gICAgfVxuXG59KSgpO1xuIl0sInNvdXJjZVJvb3QiOiIvc291cmNlLyJ9
