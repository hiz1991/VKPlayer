function SPlogin(callback) {
    var CLIENT_ID = '7b3974949bf84ea7bb249665c3eb9d9f';
    // var REDIRECT_URI = 'http://jmperezperez.com/spotify-oauth-jsfiddle-proxy/';
    var REDIRECT_URI = 'http://www.gtplayer.ru/spCallback.html';
    function getLoginURL(scopes) {
        return 'https://accounts.spotify.com/authorize?client_id=' + CLIENT_ID +
          '&redirect_uri=' + encodeURIComponent(REDIRECT_URI) +
          '&scope=' + encodeURIComponent(scopes.join(' ')) +
          '&response_type=token';
    }
    
    var url = getLoginURL([
        'user-read-email', 
        "user-library-read"
    ]);
    
    var width = 450,
        height = 730,
        left = (screen.width / 2) - (width / 2),
        top = (screen.height / 2) - (height / 2);

    window.addEventListener("message", function(event) {
        var hash = JSON.parse(event.data);
        if (hash.type == 'access_token') {
            callback(hash.access_token);
        }
    }, false);
    
    var w = window.open(url,
                        'Spotify',
                        'menubar=no,location=no,resizable=no,scrollbars=no,status=no, width=' + width + ', height=' + height + ', top=' + top + ', left=' + left
                       );
    
}

function SPgetUserData(accessToken) {
    return $.ajax({
        url: 'https://api.spotify.com/v1/me',
        headers: {
           'Authorization': 'Bearer ' + accessToken
        }
    });
}
function SPgetAllTracks(accessToken){
    return $.ajax({
        url: 'https://api.spotify.com/v1/me/tracks?limit=50',
        headers: {
           'Authorization': 'Bearer ' + accessToken
        }
    });
}

function SPChangeButton(itemID, spanText, onclick){
    $("#"+itemID+" span").text(spanText)
    $("#"+itemID).click(onclick)
}

    // SPlogin(function(accessToken) {
    //     SPgetUserData(accessToken)
    //         .then(function(response) {
    //             loginButton.style.display = 'none';
    //             resultsPlaceholder.innerHTML = template(response);
    //         });
    //     });
